#Marking guide for "DIY Django Mini Blog"

The following guide outlines a marking guide for the MDN Learning Area Django Topic � [DIY Django Mini Blog](https://developer.mozilla.org/en-US/docs/Learn/Server-side/Django/django_assessment_blog). Each subtask detailed in the assessment is listed below, along with an explanation of how many marks the task is worth, and the mark breakdown.

Note: These are guidelines, not rigid rules! As there are numerous ways of implementing this application in Django, any "sensible" mechanism that meets the requirements outlined in the assessment task would be deemed acceptable.

The overall mark awarded is out of XX. Work out their final mark, and then divide by 47 and multiply by 100 to give a percentage mark. For reference, this project (###) contains a worked example that might receive full marks. 

